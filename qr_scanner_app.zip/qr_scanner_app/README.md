# QR & Barcode Scanner — Build to Publish Guide

Follow this in order. The sequencing matters — `flutter create .` will
regenerate native scaffolding, so it must run *before* you apply the
custom Android files included here, or it can overwrite them.

## 1. Scaffold the native project

```bash
unzip qr_scanner_app.zip
cd qr_scanner_app
flutter create . --org com.yourcompany --project-name qr_scanner_app
```

This generates `android/app/src/main/kotlin/...`, Gradle wrapper files,
`ios/`, etc. It will **not** overwrite files that already exist in this
zip (AndroidManifest.xml, build.gradle, proguard-rules.pro) — Flutter's
`create` command skips existing files by default.

**Verify after running:** open `android/app/build.gradle` and confirm it
still contains the `signingConfigs` block and `applicationId
"com.yourcompany.qr_scanner_app"` — if Flutter's version somehow won, manually
replace it with the one provided in this zip.

## 2. Set your real application ID

Open `android/app/build.gradle` and `android/app/src/main/AndroidManifest.xml`,
replace `com.yourcompany.qr_scanner_app` with your actual reverse-domain ID
(e.g. `com.janedoe.qrscanner`). **Do this before your first Play Store
upload** — the application ID cannot be changed after publishing.

## 3. Install dependencies

```bash
flutter pub get
```

## 4. Add your app icon and splash assets

Read `assets/icons/README.md`. A working placeholder icon
(`app_icon.png`, `app_icon_foreground.png`, `splash_logo.png`) is already
included and will work out of the box — replace it with your own brand
art whenever you're ready, no rush to do this before testing.

Generate the native icon/splash files:

```bash
dart run flutter_launcher_icons
dart run flutter_native_splash:create
```

## 5. Run and test locally

```bash
flutter run
```

Use a **real device** for camera testing — emulator cameras are unreliable
for barcode focus/detection.

## 6. Set up release signing

```bash
keytool -genkey -v -keystore ~/upload-keystore.jks \
  -keyalg RSA -keysize 2048 -validity 10000 -alias upload
```

Copy `android/key.properties.template` to `android/key.properties`, fill
in the real password/path values. This file is gitignored — never commit
it.

## 7. Build the release bundle

```bash
flutter build appbundle --release
```

Output: `build/app/outputs/bundle/release/app-release.aab`

## 8. Host your privacy policy

`legal/privacy_policy.html` is ready to publish — fill in the date and
contact email placeholders, then host it (GitHub Pages is free and fast:
push it to a repo, enable Pages in repo settings, you'll get a public
URL in under five minutes). Play Console requires this URL since the app
requests camera permission.

## 9. Play Console submission

1. Create app in [Play Console](https://play.google.com/console)
2. Use copy from `legal/play_store_listing.md` for title/descriptions
3. Upload the `.aab` from step 7
4. Add screenshots (see shot list in `play_store_listing.md`) and a
   1024×500 feature graphic
5. Paste your hosted privacy policy URL
6. Complete the Data Safety form — since this app collects no data and
   sends nothing off-device, you'll answer "No" to data collection
   questions across the board
7. Submit for review (typically a few hours to a few days for new apps)

## What's deliberately not included (post-v1 roadmap)

- iOS build config (Android-only per MVP scope)
- AI features (suspicious link detection, barcode explainer) — the
  codebase is structured so a `services/ai_service.dart` can be added
  later without touching existing screens
- Contact-card (vCard) QR generation
- Cloud sync / backup
